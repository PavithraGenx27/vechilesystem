﻿ using System;

abstract class Vehicle
        {
           
            private string brand;

            public string Brand
            {
                get { return brand; }
                set { brand = value; }
            }

            public Vehicle(string brand)
            {
                Brand = brand;
            }

            public abstract void Start();

            public virtual void ShowInfo()
            {
                Console.WriteLine("Brand: " + Brand);
            }
        }

        class Car : Vehicle
        {
            public Car(string brand) : base(brand) { }

         
            public override void Start()
            {
                Console.WriteLine("Car started.");
            }

            public override void ShowInfo()
            {
                base.ShowInfo();
                Console.WriteLine("This is a Nexon Car.");
            }
        }

        class Motorcycle : Vehicle
        {
            public Motorcycle(string brand) : base(brand) { }

            public override void Start()
            {
                Console.WriteLine("Motorcycle started.");
            }

            public override void ShowInfo()
            {
                base.ShowInfo();
                Console.WriteLine("This is a Honda Motorcycle.");
            }
        }


class Program
{
    static void Main()
    {
        Vehicle myCar = new Car("Nexon");
        Vehicle myBike = new Motorcycle("Honda");

        myCar.Start();
        myCar.ShowInfo();

        Console.WriteLine();

        myBike.Start();
        myBike.ShowInfo();

        Console.Write("Enter your car name: ");
        Console.ReadKey();

    }

}

    
    